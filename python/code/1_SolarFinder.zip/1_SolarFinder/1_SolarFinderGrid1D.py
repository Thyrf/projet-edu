# Warning: all light sensors are analog, but some give higher values with more light, some do the opposite
# but all 4 on one solar finder work in the same way
from microbit import *

pinSensorBL = pin0
pinSensorBR = pin1
pinSensorTL = pin2
pinSensorTR = pin3

pinPan = pin13
pinTilt = pin14

pinPan.set_analog_period(10)
pinTilt.set_analog_period(10)

# set position
angleTB = 110 #TB = top/bottom; 100 => bottom ; 200: top
pinTilt.write_analog(angleTB)# angle can go from 50 to 250

# as we are using pin3 we have to disable the display
display.off()

max_light = 0 # a changer en fction min ou max
angle_max_light = 100
pinPan.write_analog(100)
sleep(1000)

for angleRL in range(100,225,5):
    pinPan.write_analog(angleRL)
    sleep(100)

    light = pinSensorBR.read_analog()+pinSensorBL.read_analog()+pinSensorTR.read_analog()+pinSensorTL.read_analog()
    print((angleRL,light,))
    if light > max_light: # if search for max => ">", if search for min => "<"
        print(angle_max_light,"=>",angleRL,"   ;   ", max_light," => ", light)
        max_light = light
        angle_max_light = angleRL

pinPan.write_analog(angle_max_light)
print("angle_max: =>",angle_max_light,"   ;   max_light => ", max_light)
