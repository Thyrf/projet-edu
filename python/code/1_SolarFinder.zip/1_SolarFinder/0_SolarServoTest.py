# pb avec big servo moteurs if analog perdio at 10 ? (sleep at 10 ms) => pb was sleep
from microbit import *

pinPan = pin13
pinTilt = pin14

pinPan.set_analog_period(10)
pinTilt.set_analog_period(10)

angleTB = 110 #pointed down
angleRL = 150 #middle

pinPan.write_analog(angleRL)# from 50 to 250
pinTilt.write_analog(angleTB)# from 50 to 250theoretically ! WARNING, do not go over 160

while True:
    if button_a.is_pressed():
        if angleRL > 50:
            angleRL -= 1
            pinPan.write_analog(angleRL)
    if button_b.is_pressed():
        if angleRL < 250:
            angleRL += 1
            pinPan.write_analog(angleRL)
    sleep(50)
