from microbit import *

pinSensorBL = pin0
pinSensorBR = pin1
pinSensorTL = pin2
pinSensorTR = pin3

pinPan = pin13
pinTilt = pin14

pinPan.set_analog_period(10)
pinTilt.set_analog_period(10)

# set position
angleTB = 150 #middle position
angleRL = 150 #middle position
pinPan.write_analog(angleRL)# angle can go from 50 to 250
pinTilt.write_analog(angleTB)

# as we are using pin3 we have to disable the display
display.off()

while True:

    diffTopBottom = (pinSensorBR.read_analog()+pinSensorBL.read_analog())-(pinSensorTR.read_analog()+pinSensorTL.read_analog())
    diffLeftRight = (pinSensorTL.read_analog()+pinSensorBL.read_analog())-(pinSensorTR.read_analog()+pinSensorBR.read_analog())

    if diffLeftRight < -10 : # more light on top
        if angleRL < 200:
            angleRL = angleRL + 0.5
            pinPan.write_analog(int(angleRL))

    if diffLeftRight > 10 : # more light on top
        if angleRL > 100:
            angleRL = angleRL - 0.5
            pinPan.write_analog(int(angleRL))

    if diffTopBottom < -10 : # more light on top
        if angleTB < 200:
            angleTB = angleTB + 0.5
            pinTilt.write_analog(int(angleTB))

    if diffTopBottom > 10 : # more light on top
        if angleTB > 100:
            angleTB = angleTB - 0.5
            pinTilt.write_analog(int(angleTB))

    print((diffTopBottom,diffLeftRight))
    sleep(10)
