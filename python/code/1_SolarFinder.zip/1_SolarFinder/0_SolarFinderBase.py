from microbit import *

# define pins
pinSensorBL = pin0 # BL = Bottom left
pinSensorBR = pin1 # Bottom right
pinSensorTL = pin2 # Top left
pinSensorTR = pin3 # Top right

pinPan = pin13 # horizontal motor
pinTilt = pin14 # vertical motor
pinPan.set_analog_period(10) 
pinTilt.set_analog_period(10) 

# set position
angleTB = 150 #middle position
angleRL = 150 #middle position
pinPan.write_analog(angleRL)# angle can go from 50 to 250 in the code but not with the robot !
pinTilt.write_analog(angleTB)

# as we are using pin3 we have to disable the display
display.off()

while True:
    light = pinSensorBR.read_analog()+pinSensorBL.read_analog()+\
            pinSensorTR.read_analog()+pinSensorTL.read_analog()
    print((light,))
    sleep(100)
