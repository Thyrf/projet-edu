from microbit import *

pinSensorBL = pin0
pinSensorBR = pin1
pinSensorTL = pin2
pinSensorTR = pin3

pinPan = pin13
pinTilt = pin14

pinPan.set_analog_period(10)
pinTilt.set_analog_period(10)

# set position
angleTB = 150 #middle position
angleRL = 150 #middle position
pinPan.write_analog(angleRL)# angle can go from 50 to 250
pinTilt.write_analog(angleTB)

# as we are using pin3 we have to disable the display
display.off()

while True:

    diffLeftRight = (pinSensorTL.read_analog()+pinSensorBL.read_analog())-(pinSensorTR.read_analog()+pinSensorBR.read_analog())

    if diffLeftRight < -10 : # more light on right
        if angleRL < 200:
            angleRL = angleRL + 0.5
            pinPan.write_analog(int(angleRL))

    if diffLeftRight > 10 : # more light on left
        if angleRL > 100:
            angleRL = angleRL - 0.5
            pinPan.write_analog(int(angleRL))

    sleep(30)
